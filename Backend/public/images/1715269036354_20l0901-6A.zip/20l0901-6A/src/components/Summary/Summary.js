import "./Summary.css";

const Summary = (props) => {
  let list = props.ing.map((obj) => {
    return (
      <li>
        {obj.name} : {obj.no}
      </li>
    );
  });
  return (
    <div className="SummaryDisplay">
      <div>Your Order</div>
      <div>Buger is Ready with following ingredients</div>
      <ul>{list}</ul>
      <p> Do you wish to Proceed to Chechkout?</p>
      <button
        style={{
          color: "red",
          border: "none",
          marginRight: "20px",
        }}
        onClick={props.cancel}
      >
        Cancel
      </button>
      <button
        style={{
          color: "green",
          border: "none",
        }}
      >
        Continue
      </button>
    </div>
  );
};
export default Summary;
