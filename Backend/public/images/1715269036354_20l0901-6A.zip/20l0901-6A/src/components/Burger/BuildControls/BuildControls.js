import BuildControl from "./BuildControl/BuildControl";
import "./BuilldControls.css";

const controls = [
  { label: "Meat", type: "meat" },
  { label: "Cheese", type: "cheese" },
  { label: "Salad", type: "salad" },
];

const BuildControls = (props) => {
  // cheching if all ingredients are zero
  const allIngredientsZero = props.ingredients.every(
    (ingredient) => ingredient.no === 0
  );

  return (
    <div className="BuildControls">
      <div>
        Current Price: <strong>{props.price}</strong>
      </div>

      {controls.map((ctrl) => {
        return (
          <BuildControl
            label={ctrl.label}
            disable={props.disable[ctrl.type]}
            add={() => props.add(ctrl.type)}
            remove={() => props.remove(ctrl.type)}
          />
        );
      })}
      <button
        className="OrderButton"
        onClick={props.showSummary}
        disabled={allIngredientsZero} // Disable if all ingredients are zero
      >
        ORDER NOW
      </button>
    </div>
  );
};
export default BuildControls;
