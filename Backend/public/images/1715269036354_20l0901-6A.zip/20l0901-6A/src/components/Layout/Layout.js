import React, { useState } from "react";
import Navbar from "./Navbar";
import Sidebar from "./Sidebar";
import Wrapper from "../../hoc/Wrapper";
import "./Layout.css";

const Layout = (props) => {
  // State to manage sidebar visibility
  const [sidebarOpen, setSidebarOpen] = useState(false);

  // Function to toggle sidebar visibility
  const toggleSidebar = () => {
    setSidebarOpen(!sidebarOpen);
  };

  return (
    <Wrapper>
      <Navbar toggleSidebar={toggleSidebar} />
      <Sidebar isOpen={sidebarOpen} toggleSidebar={toggleSidebar} />
      {/* the area under nav bar */}
      <main className="Main">{props.children}</main>
    </Wrapper>
  );
};
export default Layout;

// import Wrapper from "../../hoc/Wrapper";
// import "./Layout.css";

// const Layout = (props) => {
//   return (
//     <Wrapper>
//       <div>navbar</div>
//       <div>laeft side bar</div>
//       {/* the area under nav bar */}
//       <main className="Main">{props.children}</main>
//     </Wrapper>
//   );
// };
// export default Layout;
