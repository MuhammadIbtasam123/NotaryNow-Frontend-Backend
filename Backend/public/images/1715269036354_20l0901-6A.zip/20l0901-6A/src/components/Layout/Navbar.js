import React from "react";

const Navbar = ({ toggleSidebar }) => {
  return (
    <div
      className="Navbar"
      style={{
        backgroundColor: "yellowgreen",
        color: "#fff",
        padding: "10px",
        display: "flex",
        justifyContent: "space-between",
        alignItems: "center",
      }}
    >
      <button
        style={{
          backgroundColor: "transparent",
          color: "#fff",
          border: "none",
          fontSize: "1.5rem",
          cursor: "pointer",
        }}
        onClick={toggleSidebar}
      >
        ☰
      </button>
      <div>Navbar content</div>
    </div>
  );
};

export default Navbar;
